# Handoff: Novella-Illustrator — product page, art direction and panel renderer

## Overview
Novella-Illustrator is an open-source macOS app (Apache-2.0, distributed as a DMG) that turns a story into a comic book. You supply a story as pasted text, a PDF or URLs. The app splits it into chunks, finds the characters, and generates one scene per chunk with models you choose. Then you review, redraw and publish (PDF, self-contained animated web page, EPUB, PNG set, .mov).

The full functional spec is in `NOVELLA_SPEC.md` (requirements F1–F26). **That document is the source of truth for product behaviour.** This README covers the **visual design**: the product's look, its gothic art system, and how lettering sits on top of the generated art.

This bundle has three designs:
1. **Product page** (`Novella-Illustrator.dc.html`): the marketing/download page, with an interactive demo.
2. **Art direction** (`Art Direction.dc.html`): the house art style that every generated scene must follow. Its rules go into scene-generation prompts and review checks.
3. **Panel** (`Panel.dc.html`): a reusable comic-panel component. It draws placeholder gothic scene art and adds lettering on top: caption, speech bubble, SFX and shot label.

## About the design files
The files in this bundle are **design references created in HTML**: prototypes that show the intended look and behaviour. They are not production code to copy directly. Your job is to **recreate them in the target codebase**. The spec (section 8.2) recommends **Tauri 2 + TypeScript/React UI + Rust core**, which you should confirm with the owner first. Use that codebase's own patterns.

Each `.dc.html` file opens in a browser when `support.js` sits next to it. Styles are inline. The logic sits in a `<script>` class at the bottom of each file and works like a React class component: `renderVals()` returns the values the template reads.

## Fidelity
**High-fidelity** for colour, type, spacing, lettering and layout. Recreate these values exactly.

**Exception: the scene artwork.** Inside `Panel` the spires, arches, rose window and other scenes are CSS-built placeholders. They define composition, palette and lighting. In the real app, scene images come from the models (F14). Keep the placeholder art for empty, loading and demo states, and reuse the **lettering overlay** for real scenes.

---

## Design tokens

### Colour
| Token | Hex | Use |
|---|---|---|
| ink | `#0E0D0C` | Dark sections, nav, panel ground, outlines. Never use pure #000 except in SFX shadow |
| cream / bone | `#FAF6F1` | Light page ground, comic page paper, moonlight |
| cream-dark / parchment | `#F0E9E0` | Alternate light sections, caption boxes |
| white | `#FFFFFF` | Light cards, speech bubbles |
| rose (accent) | `#D4246E` | Buttons, eyebrows, active states, SFX, the single accent in art |
| rose-light | `#FCE8F1` | Focus ring, highlighted rows, flame core |
| gray | `#888076` | Muted labels |
| body-ink | `#6E665E` | Body copy on light (darker than gray for 4.5:1 contrast) |
| stone (art only) | `#2A2421` | Masonry, near planes |
| oxblood (art only) | `#4A0D26` | Glass falloff, deep glow |
| on-dark text | `rgba(255,255,255,.92 / .72 / .50 / .30)` | Primary / secondary / muted / faint |
| hairline light | `rgba(14,13,12,.08)`, strong `.15` | Card and divider borders on light |
| hairline dark | `rgba(255,255,255,.08)`, hover `.15` | Borders on dark |
| surface dark | `rgba(255,255,255,.04)`, raised `.07` | Cards on dark |

Dark sections use a rose glow: `radial-gradient(ellipse at <corner>, rgba(212,36,110,.22–.30), transparent 50–55%), #0E0D0C`.

### Typography
Google Fonts: **Bebas Neue**, **Cormorant Garamond** (300–500, italic), **Be Vietnam Pro** (300–600), **UnifrakturMaguntia**.

| Role | Font | Spec |
|---|---|---|
| H1 hero | Bebas Neue 400 | `clamp(60px,8vw,128px)`, lh .9, ls .04em, uppercase |
| H2 section | Bebas Neue 400 | `clamp(40px,5vw,64px)`, lh .9, ls .04em |
| H3 / card title | Bebas Neue 400 | 30–32px, ls .04em |
| Small display label | Bebas Neue | 22–26px, ls .06em |
| Lede / serif | Cormorant Garamond italic 400 | `clamp(22px,2.4vw,30px)`, lh 1.3; section ledes 22px/1.4 |
| Body | Be Vietnam Pro 300 | 15px / 1.8 |
| Eyebrow | Be Vietnam Pro 600 | 11px, ls .2em, uppercase, rose |
| Field label | Be Vietnam Pro 600 | 10px, ls .2em, `rgba(255,255,255,.5)` |
| Button / nav | Be Vietnam Pro 600 | 11–12px, ls .14em, uppercase |
| Micro tag | Be Vietnam Pro 600 | 8–9px, ls .22em |
| Wordmark / numerals | UnifrakturMaguntia | Wordmark 28px (nav), `clamp(64px,10vw,140px)` (footer); step numerals 40–44px rose. **Only for the wordmark, roman numerals and chapter title cards. Never in body text or panels.** |

Wordmark: "Novella" in UnifrakturMaguntia rose + "ILLUSTRATOR" in Bebas, ls .2em (nav) / .3em (footer).

### Spacing, radius, shadow, motion
- Spacing rhythm: 4, 8, 12, 16, 20, 24, 32, 40, 48, 56, 64, 80, 100.
- Section padding: `clamp(64px,8vw,100px)` vertical, `clamp(20px,4vw,64px)` horizontal. Max content width 1400px (hero, galleries) or 1160px (text sections).
- Radius: pill `9999px` (buttons, chips, segmented controls), `20px` large cards, `12px` inputs/small cards, `6px` minor. **Comic panels have 0 radius.**
- Shadows: comic page `0 30px 80px rgba(0,0,0,.6), 0 0 0 1px rgba(255,255,255,.08)`. Featured dark card `0 8px 24px rgba(212,36,110,.12)`. Focus `0 0 0 3px #FCE8F1`, or `0 0 0 3px rgba(212,36,110,.25)` on dark.
- Motion: hover `.2s ease`, button `.22s ease` with lift −1px and opacity .85. No bounces.

---

## Screens

### 1. Product page (`Novella-Illustrator.dc.html`)
Full-bleed sections alternate dark and light.

1. **Nav** (sticky, `rgba(14,13,12,.94)` + `backdrop-filter: blur(8px)`, min-height 56px, wraps on narrow screens). Wordmark on the left. Links on the right: HOW IT WORKS, HOUSE STYLE, MODELS, ART DIRECTION. A rose pill CTA: DOWNLOAD FOR MAC.
2. **Hero** (dark + glow top right)
   - Eyebrow: "OPEN-SOURCE COMIC MAKER FOR MAC"
   - H1: "YOUR STORY, / INKED IN THE DARK."
   - Serif lede: "Paste a story, drop in a PDF or a few links. Novella-Illustrator splits it into chunks, casts your characters and draws a gothic scene for each chunk."
   - **Demo**: a two-column grid, `repeat(auto-fit, minmax(min(100%,400px),1fr))`, gap 40.
     - **Left card** (`rgba(255,255,255,.04)`, 20px radius, 28px padding):
       - Story textarea: ink ground, Cormorant italic 20px, rose focus ring.
       - "OR BORROW ONE": three pill chips with the sample stories. The active chip is filled rose.
       - Two segmented pill controls: PAGE LAYOUT (GRID / SPLASH / SCROLL) and TREATMENT (INK / WOODCUT / ROSE). The active segment is filled rose.
       - Primary button "DRAW MY PAGE →" with an italic status line beside it.
     - **Right side**: a title row (story title in Bebas 26px, "four chunks, four scenes" in italic), then the comic page. The page is cream paper with 12px padding, a 9px gutter and a CSS grid of 4 Panels.
3. **How it works** (cream). Six white cards in an auto-fit grid (min 300px), each with a roman numeral I–VI, a Bebas title and a body paragraph: Bring a story · Cut it into chunks · Cast the characters · Draw the storyline · Review and redraw · Publish. Copy is in the file.
4. **Chunk view** (`#F0E9E0`). The left card shows the full story, with each chunk's span highlighted (alternating rose-light and parchment backgrounds, each with a 2px inset underline in rose or ink) and superscript chunk numbers. A granularity bar sits below it. On the right are four chunk rows: a 120px 4:3 Panel thumbnail, "CHUNK n · SCENE TYPE" and an italic summary. The selected row has a rose border and a 3px rose-light ring, plus "REDRAW WITH ANOTHER MODEL ↻". This previews F10, F24, F25 and F16.
5. **House style** (dark + glow bottom left). H2 "INK, BONE AND ONE ROSE", an outline pill "READ THE ART DIRECTION ↗", and a gallery of the 6 scene Panels (4:3, auto-fill min 300px) with names and italic notes.
6. **Models** (cream). Copy on the left. On the right, a cost-versus-performance card (F18) for one prompt stage with three rows: model name and source, estimated cost, and a fit score as 5 dots. The suggested row has a rose-light background and a "✦ SUGGESTED" pill. Footnote: costs are estimates read from a price file. **Model names and prices are placeholders.**
7. **Publish + privacy** (dark). Five format pills (PDF, ANIMATED WEB PAGE, EPUB, PNG SET, VIDEO .MOV). On the right, a ruled list: On your drive · No telemetry · Apache-2.0.
8. **Footer / download** (cream). Large wordmark, the italic line "You bring the story. Novella brings the candles.", buttons DOWNLOAD THE DMG (ink pill) and SOURCE ON GITHUB ↗ (outline), and a legal row.

### 2. Art direction (`Art Direction.dc.html`)
A reference doc that is also a prompt and QA source. Sections: Cover · 01 Principles · 02 Palette (with a proportion bar ink 7 : stone 1.6 : bone 1.2 : oxblood .7 : rose .5) · 03 Lettering · 04 Surface textures · 05 The six rooms · 06 Treatments · 07 Panel grammar · 08 Never list. All copy is in the file. The key rules are below.

### 3. Panel (`Panel.dc.html`)
| Prop | Values |
|---|---|
| `scene` | `spires` · `window` · `corridor` · `rose` · `gate` · `candle` |
| `treatment` | `ink` (default) · `woodcut` (art layer `filter: invert(1) hue-rotate(180deg) contrast(1.08)`) · `rose` (overlay `#D4246E`, `mix-blend-mode: color`, opacity .9) |
| `caption`, `line`, `speaker`, `sfx`, `shot` | strings; each element renders only when its string is non-empty |

Layer order: art layer (scene, then crosshatch overlay, then halftone, then vignette) → treatment overlay → lettering. Treatments never affect the lettering.

- Root: `container-type: size`, 2px ink outline, no radius, `overflow: hidden`. Lettering sizes use `cqw` units, so text scales with the panel.
- **Caption**: top 8px / left 8px, max-width 68%, `#F0E9E0` background, 1.5px ink border, padding 5px 9px 6px. Cormorant italic 500, `clamp(12px,4.4cqw,17px)`, lh 1.22. Hard shadow `3px 3px 0 #0E0D0C`.
- **Bubble**: right 8px / bottom 28px, max-width 62%, white, 1.5px ink border, 16px radius, padding 6px 11px 7px. Speaker tag: 8px, 600, ls .22em, rose. Line: Be Vietnam Pro 500, `clamp(10px,3.4cqw,13px)`, uppercase, ls .03em. Tail: an 11px square rotated 45° at bottom −7px / left 20px, with right and bottom borders only.
- **SFX**: top 30% / left 7%. Bebas `clamp(26px,14cqw,64px)`, rose, `text-shadow: 3px 3px 0 #0E0D0C, -1px -1px 0 #0E0D0C`, rotated −9°.
- **Shot label**: bottom 7px / left 9px. 8px, 600, ls .22em, uppercase, `rgba(255,255,255,.72)`.
- Textures: crosshatch `repeating-linear-gradient(45deg, rgba(14,13,12,.16) 0 1px, transparent 1px 5px)`; halftone `radial-gradient(rgba(250,246,241,.09) 1px, transparent 1.4px) 0 0/5px 5px`; vignette `radial-gradient(ellipse at center, transparent 48%, rgba(14,13,12,.78) 100%)`.
- Pointed-arch clip-path (used throughout): `polygon(0% 100%, 0% 35%, 1.5% 28%, 6% 21.2%, 13.4% 14.8%, 23.4% 9%, 35.7% 4%, 50% 0%, 64.3% 4%, 76.6% 9%, 86.6% 14.8%, 94% 21.2%, 98.5% 28%, 100% 35%, 100% 100%)`.

---

## Art system → app behaviour
Connect these to the spec:
- **Scene type → room** (F9 classifies scene types): landscape → spires · drama → window · movement → corridor (arches) · revelation → rose · threshold → gate · human figure / close dialogue → candle. Use the room as the composition hint in scene prompts.
- **Style prompt block**, added to every scene generation: one light source (moon, window or flame); about 70% ink; bone only where light lands; rose under 10% of the frame, on the focal detail; flat fills, crosshatching, halftone; printed rather than rendered; characters readable by silhouette and locked to the cast sheet (F13).
- **Negative prompt / review flags** (F15–F17), from the "Never" list: glossy or airbrushed skin; lens flare, bokeh, god rays; purple-to-teal gradients or any extra hue; extra fingers or melted architecture; text painted into the art; symmetry in every panel; fantasy-poster fonts; a character's face changing between chunks.
- **Lettering is always an overlay**, never generated into the image. Use the Panel lettering spec in the app's storyline and review views and in every export (F19–F21).
- **Page grammar** (open item 5 in spec section 12, to propose to the owner): 4 panels per page by default; 2px ink frame; 9px gutter; 12px page margin; a splash panel bleeds off the edge; reading order left to right, top to bottom; caption top left, bubble bottom right, shot label bottom left. Layout presets:
  - GRID: `cols 1fr 1fr / rows 1fr 1fr / areas "a b" "c d"`
  - SPLASH: `cols 1.2fr 1fr / rows 1.1fr 1fr .9fr / areas "a a" "b c" "d d"`
  - SCROLL: one column, 4 rows (use for the vertical/animated web export)

## Interactions and state (product page demo)
State: `text`, `story {title, panels[4]}`, `revealed` (0–4), `busy`, `status`, `layout`, `treatment`.
1. Clicking a sample chip sets `text`. A chip is active when `text` matches its sample exactly.
2. **DRAW MY PAGE** (ignored while busy): `revealed=0` and status "Reading your story…".
   - If the text matches a sample, the demo uses that sample's preset panels after 700ms.
   - Otherwise it asks an LLM for JSON: `{title, panels:[{scene, shot, caption, line, speaker, sfx}×4]}`, with scene restricted to the six rooms.
   - If the LLM call fails, it splits the text into sentences and uses the first four as captions.
   - Panels then reveal one at a time, 520ms apart ("Drawing chunk n of 4…"). Unrevealed panels show a dashed ghost labelled "CHUNK 0n · DRAWING".
   - At the end: "Page one is ready for review."
3. Layout and treatment segments change the page immediately. While busy, the button shows "DRAWING…" at opacity .6.

Responsive: every multi-column block uses `repeat(auto-fit, minmax(min(100%, Npx), 1fr))`, and the nav wraps. Section padding uses the clamps above.

## Accessibility
- Body copy on light uses `#6E665E`, not `#888076`, to meet 4.5:1.
- Keep visible focus rings.
- The segmented controls should become proper radio groups in production.
- Panel art is decorative. The caption and line text carry the meaning and need screen-reader labels (spec section 9).

## Assets
No raster assets. The scene art is CSS. Fonts come from Google Fonts (all OFL); add them to the third-party licence ledger (spec section 10).

## Files
- `NOVELLA_SPEC.md`: product spec, the source of truth for behaviour (F1–F26, milestones M0–M8)
- `Novella-Illustrator.dc.html`: product page and demo
- `Art Direction.dc.html`: art system reference
- `Panel.dc.html`: panel component (scenes, treatments, lettering)
- `support.js`: runtime needed to open the `.dc.html` files in a browser

## Placeholders to replace
- Model names and prices in the cost card
- Download and GitHub links (they point to `#download`)
- The demo's "draw" step: the real app runs model generation as background jobs (spec section 5.6)
